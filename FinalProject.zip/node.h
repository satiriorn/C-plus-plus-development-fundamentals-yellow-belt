#pragma once

#include "date.h"

#include <string>
#include <memory>

enum class Comparison {
    Less,
    LessOrEqual,
    Greater,
    GreaterOrEqual,
    Equal,
    NotEqual
};

enum class LogicalOperation {
    And,
    Or
};

class Node {
public:
    Node(const Date& date, const string& event);
    virtual bool Evaluate(const Date& date, const string& event) const = 0;
protected:
    const Date date_;
    const string event_;
};

class EmptyNode : public Node {
public:
    EmptyNode();
    bool Evaluate(const Date& date, const string& event) const override;
};

class DateComparisonNode : public Node {
public:
    DateComparisonNode (const Comparison& comparison, const Date& date);
    bool Evaluate(const Date& date, const string& event) const override;
private:
    const Comparison comparison_;
};

class EventComparisonNode : public Node {
public:
    EventComparisonNode (const Comparison& comparison, const string& event);
    bool Evaluate(const Date& date, const string& event) const override;
private:
    const Comparison comparison_;
};

class LogicalOperationNode : public Node {
public:
    LogicalOperationNode(const LogicalOperation& logical_operation,
            const shared_ptr<Node>& left_node, const shared_ptr<Node>& right_node);
    bool Evaluate(const Date& date, const string& event) const override;
private:
    const LogicalOperation logical_operation_;
    const shared_ptr<Node> left_node_, right_node_;
};