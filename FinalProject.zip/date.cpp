#include "date.h"

#include <iomanip>
#include <sstream>
#include <tuple>

Date::Date() : year(0), month(0), day(0) {}

Date::Date(const int& Year, const int& Month, const int& Day):year(Year), month(Month), day(Day){}

int Date::GetYear() const{ return year; }
int Date::GetDay() const{ return day; }
int Date::GetMonth() const{ return month; }

void Error(string name, string data_str) {
	stringstream string_error;
	string_error << name + data_str;
	throw runtime_error(string_error.str());
}

inline void Check(stringstream& stream, const string& data_str) {
	if (stream.peek() != '-')
		Error("Wrong date format: ", data_str);
	stream.ignore(1);
}

Date ParseDate(istream& stream) {
	int year, month, day;
	year = month = day = 0;
	string data_str;
	if (stream >> data_str) {
		stringstream d(data_str);
		d >> year;
		Check(d, data_str);
		d >> month;
		Check(d, data_str);
		d >> day;
		if (year > -1 && year < 10000 && month < 10000 && day < 10000 && month>0 && day>0) 
			return Date(year, month, day);
		else
			Error("Wrong date format: ", data_str);
	}
	else
		Error("Wrong date format: ", data_str);

}

ostream& operator << (ostream& stream, const Date& date) {
  stream << setw(4) << setfill('0') << date.GetYear() << '-'
    << setw(2) << setfill('0') << date.GetMonth() << '-'
    << setw(2) << setfill('0') << date.GetDay();
  return stream;
}

bool operator < (const Date& lhs, const Date& rhs){
	return make_tuple(lhs.GetYear(), lhs.GetMonth(), lhs.GetDay()) < 
		   make_tuple(rhs.GetYear(), rhs.GetMonth(), rhs.GetDay());
}

bool operator == (const Date& lhs, const Date& rhs){
	return make_tuple(lhs.GetYear(), lhs.GetMonth(), lhs.GetDay()) ==
		   make_tuple(rhs.GetYear(), rhs.GetMonth(), rhs.GetDay());
}
