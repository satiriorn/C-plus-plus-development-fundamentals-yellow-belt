#include "node.h"

Node::Node(const Date& date, const string& event): date_(date), event_(event) {}

EmptyNode::EmptyNode() : Node(Date(), "") {}

bool EmptyNode::Evaluate(const Date& date, const string& event) const {return true;}

DateComparisonNode::DateComparisonNode(const Comparison &comparison, const Date &date): comparison_(comparison), Node(date, "") {}

bool DateComparisonNode::Evaluate(
        const Date& date, const string& event) const {
    switch (comparison_) {
        case Comparison::Less:
            return date < date_;
        case Comparison::LessOrEqual:
            return !(date_ < date);
        case Comparison::Greater:
            return date_ < date;
        case Comparison::GreaterOrEqual:
            return !(date < date_);
        case Comparison::Equal:
            return date == date_;
        case Comparison::NotEqual:
            return !(date == date_);
    }
}

EventComparisonNode::EventComparisonNode(const Comparison &comparison, const string &event):comparison_(comparison), Node(Date(), event){}

bool EventComparisonNode::Evaluate(const Date& date,
        const string& event) const {
    switch (comparison_) {
        case Comparison::Less:
            return event < event_;
        case Comparison::LessOrEqual:
            return event <= event_;
        case Comparison::Greater:
            return event_ < event;
        case Comparison::GreaterOrEqual:
            return event_ <= event;
        case Comparison::Equal:
            return event == event_;
        case Comparison::NotEqual:
            return event != event_;
    }
}

LogicalOperationNode::LogicalOperationNode(
        const LogicalOperation& logical_operation,
        const shared_ptr<Node>& left_node, const shared_ptr<Node>& right_node)
        : logical_operation_(logical_operation)
        , left_node_(left_node), right_node_(right_node)
        , Node(Date(), "") {
}

bool LogicalOperationNode::Evaluate(const Date& date,const string& event) const {
    switch (logical_operation_) {
        case LogicalOperation::And:
            return left_node_->Evaluate(date, event) &&
                    right_node_->Evaluate(date, event);
        case LogicalOperation::Or:
            return left_node_->Evaluate(date, event) ||
                    right_node_->Evaluate(date, event);
    }
}