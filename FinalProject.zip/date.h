#pragma once

#include <string>
#include <iostream>

using namespace std;

class Date {
public:
    Date();
    Date (const int& Year, const int& Month, const int& Day);
	int GetDay() const;
	int GetMonth() const;
	int GetYear() const;
private:
	const int year;
	const int month;
	const int day;
};

Date ParseDate(istream& stream);

ostream& operator<<(ostream& stream, const Date& date);

bool operator<(const Date& lhs, const Date& rhs);

bool operator==(const Date& lhs, const Date& rhs);

